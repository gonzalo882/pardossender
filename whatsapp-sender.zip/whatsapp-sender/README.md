# WhatsApp Sender — ProEX

Mini app para envio de mensagens WhatsApp via Z-API a partir de uma spreadsheet.

---

## Pré-requisitos

- [Node.js](https://nodejs.org/) v18+ instalado
- Conta Z-API em https://app.z-api.io (2 dias grátis)
- Número de WhatsApp ligado à instância Z-API

---

## Arrancar a app

```bash
chmod +x start.sh
./start.sh
```

Abre automaticamente em **http://localhost:3000**

### Ou manualmente (2 terminais):

**Terminal 1 — Backend:**
```bash
cd backend
npm install
node server.js
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm install
npm start
```

---

## Formato da Spreadsheet

O ficheiro pode ser `.xlsx`, `.xls` ou `.csv` com estas colunas (os nomes não são case-sensitive):

| nome | whatsapp | mensagem |
|------|----------|----------|
| João Silva | 351912345678 | Olá João, temos uma novidade para si... |
| Ana Costa | 351961234567 | Boa tarde Ana, a sua proposta está pronta. |

**Dicas:**
- O número pode ter ou não o `+351` — a app normaliza automaticamente
- Cada linha pode ter uma mensagem diferente e personalizada
- Números sem indicativo: a app assume `+351` (Portugal)

---

## Configuração Z-API

1. Acede a https://app.z-api.io
2. Cria uma instância e liga o teu número via QR code
3. Copia o **Instance ID** e o **Token** (no painel da instância)
4. Cola-os na app antes de carregar o ficheiro

---

## Boas práticas (evitar ban)

- ✅ Usa um número secundário, não o teu principal
- ✅ Delay de 5–10 segundos entre mensagens
- ✅ Mensagens personalizadas (não texto idêntico para todos)
- ✅ Não enviar mais de 100–150 msgs por sessão
- ❌ Não enviar para números desconhecidos ou listas compradas

---

## Funcionalidades

- Upload .xlsx / .xls / .csv
- Preview dos contactos antes de enviar
- Barra de progresso em tempo real
- Estado por contacto (pendente / a enviar / enviado / erro)
- Botão de parar a qualquer momento
- Retentar apenas os que falharam
