const express = require('express');
const cors = require('cors');
const multer = require('multer');
const XLSX = require('xlsx');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

// Parse spreadsheet
app.post('/api/parse', upload.single('file'), (req, res) => {
  try {
    const workbook = XLSX.readFile(req.file.path);
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet);
    fs.unlinkSync(req.file.path);

    // Normalize columns (case-insensitive)
    const contacts = rows.map((row, i) => {
      const keys = Object.keys(row);
      const find = (patterns) => {
        const k = keys.find(k => patterns.some(p => k.toLowerCase().includes(p)));
        return k ? String(row[k]).trim() : '';
      };
      return {
        id: i + 1,
        nome: find(['nome', 'name', 'contact']),
        telefone: find(['whatsapp', 'telefone', 'phone', 'numero', 'number', 'tel']),
        mensagem: find(['mensagem', 'message', 'msg', 'texto', 'text']),
        status: 'pending'
      };
    }).filter(c => c.telefone);

    res.json({ success: true, contacts });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// Send a single message via Z-API
app.post('/api/send', async (req, res) => {
  const { instanceId, token, phone, message } = req.body;

  // Normalize phone: remove spaces, dashes, +
  let cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
  if (!cleanPhone.startsWith('+')) {
    // If no country code, assume PT (+351) or as-is
    if (!cleanPhone.startsWith('351') && cleanPhone.length <= 9) {
      cleanPhone = '351' + cleanPhone;
    }
  } else {
    cleanPhone = cleanPhone.substring(1);
  }

  const url = `https://api.z-api.io/instances/${instanceId}/token/${token}/send-text`;

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'client-token': token },
      body: JSON.stringify({ phone: cleanPhone, message })
    });

    const data = await response.json();

    if (response.ok && (data.zaapId || data.messageId || data.id)) {
      res.json({ success: true, data });
    } else {
      res.json({ success: false, error: data.message || data.error || JSON.stringify(data) });
    }
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

app.listen(3001, () => console.log('Backend running on http://localhost:3001'));
