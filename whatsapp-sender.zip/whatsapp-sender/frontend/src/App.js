import React, { useState, useRef, useCallback } from 'react';
import axios from 'axios';

const API = 'http://localhost:3001/api';

const styles = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: #0a0a0a;
    color: #e8e8e8;
    font-family: 'DM Sans', sans-serif;
    min-height: 100vh;
  }

  .app {
    max-width: 860px;
    margin: 0 auto;
    padding: 48px 24px 80px;
  }

  .header {
    margin-bottom: 48px;
  }

  .header-tag {
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    letter-spacing: 0.18em;
    color: #25D366;
    text-transform: uppercase;
    margin-bottom: 12px;
  }

  .header h1 {
    font-size: 32px;
    font-weight: 300;
    color: #fff;
    letter-spacing: -0.02em;
    line-height: 1.2;
  }

  .header h1 span {
    color: #25D366;
    font-weight: 600;
  }

  .header p {
    margin-top: 10px;
    font-size: 14px;
    color: #555;
    line-height: 1.6;
  }

  /* CARD */
  .card {
    background: #111;
    border: 1px solid #1e1e1e;
    border-radius: 12px;
    padding: 28px;
    margin-bottom: 16px;
  }

  .card-title {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    letter-spacing: 0.16em;
    color: #444;
    text-transform: uppercase;
    margin-bottom: 20px;
  }

  /* INPUTS */
  .field { margin-bottom: 16px; }

  .field label {
    display: block;
    font-size: 12px;
    color: #666;
    margin-bottom: 6px;
    font-family: 'DM Mono', monospace;
    letter-spacing: 0.05em;
  }

  .field input, .field select {
    width: 100%;
    background: #0a0a0a;
    border: 1px solid #222;
    border-radius: 8px;
    padding: 11px 14px;
    color: #e8e8e8;
    font-family: 'DM Mono', monospace;
    font-size: 13px;
    outline: none;
    transition: border-color 0.2s;
  }

  .field input:focus, .field select:focus {
    border-color: #25D366;
  }

  .field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }

  /* DROP ZONE */
  .dropzone {
    border: 1.5px dashed #222;
    border-radius: 10px;
    padding: 40px 24px;
    text-align: center;
    cursor: pointer;
    transition: all 0.2s;
    background: #0a0a0a;
  }

  .dropzone:hover, .dropzone.dragover {
    border-color: #25D366;
    background: #0d1a10;
  }

  .dropzone-icon {
    font-size: 28px;
    margin-bottom: 10px;
    opacity: 0.6;
  }

  .dropzone p {
    font-size: 13px;
    color: #555;
    line-height: 1.6;
  }

  .dropzone p strong {
    color: #25D366;
    font-weight: 500;
  }

  .dropzone .file-types {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    color: #333;
    margin-top: 8px;
    letter-spacing: 0.1em;
  }

  /* TABLE */
  .table-wrap {
    overflow-x: auto;
    margin-top: 4px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
  }

  th {
    text-align: left;
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    letter-spacing: 0.1em;
    color: #444;
    padding: 0 12px 12px;
    text-transform: uppercase;
    border-bottom: 1px solid #1e1e1e;
  }

  td {
    padding: 12px;
    border-bottom: 1px solid #161616;
    vertical-align: top;
    color: #ccc;
  }

  tr:last-child td { border-bottom: none; }

  .status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    letter-spacing: 0.08em;
    padding: 3px 8px;
    border-radius: 4px;
    white-space: nowrap;
  }

  .status-pending { background: #1a1a1a; color: #555; }
  .status-sending { background: #0d1a30; color: #4a9eff; }
  .status-sent    { background: #0d1a10; color: #25D366; }
  .status-error   { background: #1a0d0d; color: #ff4a4a; }

  .msg-preview {
    max-width: 220px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #555;
    font-size: 12px;
  }

  /* PROGRESS */
  .progress-wrap {
    background: #0a0a0a;
    border-radius: 4px;
    height: 4px;
    margin: 16px 0 8px;
    overflow: hidden;
  }

  .progress-bar {
    height: 100%;
    background: #25D366;
    border-radius: 4px;
    transition: width 0.3s ease;
  }

  .progress-label {
    font-family: 'DM Mono', monospace;
    font-size: 11px;
    color: #444;
    display: flex;
    justify-content: space-between;
  }

  /* BUTTONS */
  .btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    font-family: 'DM Sans', sans-serif;
    cursor: pointer;
    border: none;
    transition: all 0.15s;
    white-space: nowrap;
  }

  .btn-primary {
    background: #25D366;
    color: #000;
  }
  .btn-primary:hover:not(:disabled) { background: #1ebe5a; }
  .btn-primary:disabled { opacity: 0.35; cursor: not-allowed; }

  .btn-ghost {
    background: transparent;
    color: #555;
    border: 1px solid #222;
  }
  .btn-ghost:hover { border-color: #444; color: #999; }

  .btn-danger {
    background: #1a0d0d;
    color: #ff4a4a;
    border: 1px solid #2a1010;
  }
  .btn-danger:hover { background: #2a1010; }

  .actions {
    display: flex;
    gap: 10px;
    margin-top: 20px;
    flex-wrap: wrap;
  }

  /* STATS */
  .stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-top: 4px;
  }

  .stat {
    background: #0a0a0a;
    border: 1px solid #1a1a1a;
    border-radius: 8px;
    padding: 14px 16px;
  }

  .stat-value {
    font-size: 24px;
    font-weight: 300;
    color: #fff;
    line-height: 1;
    margin-bottom: 4px;
  }

  .stat-label {
    font-family: 'DM Mono', monospace;
    font-size: 10px;
    color: #444;
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }

  .stat-sent .stat-value { color: #25D366; }
  .stat-error .stat-value { color: #ff4a4a; }

  /* DELAY HINT */
  .hint {
    font-size: 11px;
    color: #333;
    margin-top: 6px;
    font-family: 'DM Mono', monospace;
  }

  /* ALERT */
  .alert {
    border-radius: 8px;
    padding: 12px 16px;
    font-size: 13px;
    margin-bottom: 16px;
    line-height: 1.5;
  }
  .alert-warn { background: #1a1500; border: 1px solid #2a2200; color: #aa8800; }
  .alert-info { background: #0d1a30; border: 1px solid #102040; color: #4a9eff; }

  @media (max-width: 600px) {
    .field-row { grid-template-columns: 1fr; }
    .stats { grid-template-columns: repeat(2, 1fr); }
  }
`;

const STEPS = { CONFIG: 0, UPLOAD: 1, PREVIEW: 2, SENDING: 3, DONE: 4 };

export default function App() {
  const [step, setStep] = useState(STEPS.CONFIG);
  const [config, setConfig] = useState({ instanceId: '', token: '', delay: 5 });
  const [contacts, setContacts] = useState([]);
  const [dragover, setDragover] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const [stopped, setStopped] = useState(false);
  const stopRef = useRef(false);
  const fileRef = useRef();

  const stats = {
    total: contacts.length,
    sent: contacts.filter(c => c.status === 'sent').length,
    error: contacts.filter(c => c.status === 'error').length,
    pending: contacts.filter(c => c.status === 'pending').length,
  };

  const handleFile = useCallback(async (file) => {
    if (!file) return;
    setUploading(true);
    const fd = new FormData();
    fd.append('file', file);
    try {
      const { data } = await axios.post(`${API}/parse`, fd);
      if (data.success) {
        setContacts(data.contacts);
        setStep(STEPS.PREVIEW);
      } else {
        alert('Erro ao ler ficheiro: ' + data.error);
      }
    } catch (e) {
      alert('Não foi possível contactar o backend. Tens o servidor a correr? (npm start na pasta backend)');
    }
    setUploading(false);
  }, []);

  const handleDrop = (e) => {
    e.preventDefault();
    setDragover(false);
    handleFile(e.dataTransfer.files[0]);
  };

  const startSending = async () => {
    setSending(true);
    setStopped(false);
    stopRef.current = false;
    setStep(STEPS.SENDING);

    for (let i = 0; i < contacts.length; i++) {
      if (stopRef.current) break;
      const c = contacts[i];
      if (c.status === 'sent') continue;

      setContacts(prev => prev.map(x => x.id === c.id ? { ...x, status: 'sending' } : x));

      try {
        const { data } = await axios.post(`${API}/send`, {
          instanceId: config.instanceId,
          token: config.token,
          phone: c.telefone,
          message: c.mensagem,
        });

        setContacts(prev => prev.map(x => x.id === c.id
          ? { ...x, status: data.success ? 'sent' : 'error', error: data.error }
          : x));
      } catch {
        setContacts(prev => prev.map(x => x.id === c.id ? { ...x, status: 'error', error: 'Erro de rede' } : x));
      }

      if (i < contacts.length - 1 && !stopRef.current) {
        await new Promise(r => setTimeout(r, config.delay * 1000));
      }
    }

    setSending(false);
    setStep(STEPS.DONE);
  };

  const stop = () => {
    stopRef.current = true;
    setStopped(true);
  };

  const reset = () => {
    setContacts([]);
    setStep(STEPS.CONFIG);
    setSending(false);
    setStopped(false);
  };

  const configValid = config.instanceId.trim() && config.token.trim();
  const progress = stats.total > 0 ? Math.round(((stats.sent + stats.error) / stats.total) * 100) : 0;

  return (
    <>
      <style>{styles}</style>
      <div className="app">
        <div className="header">
          <div className="header-tag">● ProEX Tooling</div>
          <h1>WhatsApp <span>Sender</span></h1>
          <p>Carrega a tua spreadsheet, configura a Z-API e envia mensagens personalizadas em massa.</p>
        </div>

        {/* STEP 0: Config */}
        <div className="card">
          <div className="card-title">01 — Configuração Z-API</div>

          <div className="alert alert-warn">
            ⚠ Usa um <strong>número secundário</strong> para envios em massa. O teu número principal pode ser banido pelo WhatsApp se detetarem padrão de spam.
          </div>

          <div className="field-row">
            <div className="field">
              <label>Instance ID</label>
              <input
                value={config.instanceId}
                onChange={e => setConfig(p => ({ ...p, instanceId: e.target.value }))}
                placeholder="ex: 3C4A9..."
                disabled={sending}
              />
            </div>
            <div className="field">
              <label>Token</label>
              <input
                value={config.token}
                onChange={e => setConfig(p => ({ ...p, token: e.target.value }))}
                placeholder="ex: F23BC1..."
                type="password"
                disabled={sending}
              />
            </div>
          </div>

          <div className="field" style={{ maxWidth: 200 }}>
            <label>Delay entre mensagens (segundos)</label>
            <input
              type="number"
              min="2"
              max="60"
              value={config.delay}
              onChange={e => setConfig(p => ({ ...p, delay: Number(e.target.value) }))}
              disabled={sending}
            />
            <div className="hint">↳ recomendado: 5–10s para evitar ban</div>
          </div>

          {step === STEPS.CONFIG && (
            <div className="actions">
              <button className="btn btn-primary" disabled={!configValid} onClick={() => setStep(STEPS.UPLOAD)}>
                Continuar →
              </button>
            </div>
          )}
        </div>

        {/* STEP 1: Upload */}
        {step >= STEPS.UPLOAD && (
          <div className="card">
            <div className="card-title">02 — Ficheiro de Contactos</div>

            <div
              className={`dropzone ${dragover ? 'dragover' : ''}`}
              onDragOver={e => { e.preventDefault(); setDragover(true); }}
              onDragLeave={() => setDragover(false)}
              onDrop={handleDrop}
              onClick={() => fileRef.current?.click()}
            >
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                style={{ display: 'none' }}
                onChange={e => handleFile(e.target.files[0])}
              />
              <div className="dropzone-icon">📋</div>
              {uploading
                ? <p>A processar...</p>
                : <>
                    <p><strong>Clica ou arrasta</strong> o teu ficheiro aqui</p>
                    <div className="file-types">.XLSX · .XLS · .CSV</div>
                    <p style={{ marginTop: 12, fontSize: 11, color: '#333' }}>
                      Colunas esperadas: <span style={{ color: '#444' }}>nome · whatsapp · mensagem</span>
                    </p>
                  </>
              }
            </div>
          </div>
        )}

        {/* STEP 2+: Preview & Results */}
        {contacts.length > 0 && (
          <div className="card">
            <div className="card-title">
              {step <= STEPS.PREVIEW ? '03 — Preview' : step === STEPS.SENDING ? '03 — A Enviar...' : '03 — Resultados'}
            </div>

            {step >= STEPS.SENDING && (
              <>
                <div className="stats">
                  <div className="stat">
                    <div className="stat-value">{stats.total}</div>
                    <div className="stat-label">Total</div>
                  </div>
                  <div className="stat stat-sent">
                    <div className="stat-value">{stats.sent}</div>
                    <div className="stat-label">Enviados</div>
                  </div>
                  <div className="stat stat-error">
                    <div className="stat-value">{stats.error}</div>
                    <div className="stat-label">Erros</div>
                  </div>
                  <div className="stat">
                    <div className="stat-value">{stats.pending}</div>
                    <div className="stat-label">Pendentes</div>
                  </div>
                </div>

                <div className="progress-wrap">
                  <div className="progress-bar" style={{ width: `${progress}%` }} />
                </div>
                <div className="progress-label">
                  <span>{progress}% concluído</span>
                  {sending && <span style={{ color: '#25D366' }}>● a enviar...</span>}
                  {stopped && <span style={{ color: '#ff4a4a' }}>■ parado</span>}
                </div>
              </>
            )}

            <div className="table-wrap" style={{ marginTop: 20 }}>
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>WhatsApp</th>
                    <th>Mensagem</th>
                    <th>Estado</th>
                  </tr>
                </thead>
                <tbody>
                  {contacts.map(c => (
                    <tr key={c.id}>
                      <td style={{ color: '#333', fontFamily: 'DM Mono', fontSize: 11 }}>{c.id}</td>
                      <td>{c.nome || <span style={{ color: '#333' }}>—</span>}</td>
                      <td style={{ fontFamily: 'DM Mono', fontSize: 12 }}>{c.telefone}</td>
                      <td><div className="msg-preview">{c.mensagem}</div></td>
                      <td>
                        <StatusBadge status={c.status} error={c.error} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="actions">
              {step === STEPS.PREVIEW && (
                <>
                  <button className="btn btn-primary" onClick={startSending}>
                    ▶ Enviar {stats.total} mensagens
                  </button>
                  <button className="btn btn-ghost" onClick={() => { setContacts([]); setStep(STEPS.UPLOAD); }}>
                    ← Trocar ficheiro
                  </button>
                </>
              )}
              {step === STEPS.SENDING && sending && (
                <button className="btn btn-danger" onClick={stop}>
                  ■ Parar
                </button>
              )}
              {(step === STEPS.DONE || stopped) && (
                <>
                  {stats.error > 0 && (
                    <button className="btn btn-primary" onClick={() => {
                      setContacts(prev => prev.map(c => c.status === 'error' ? { ...c, status: 'pending' } : c));
                      setStep(STEPS.PREVIEW);
                    }}>
                      ↺ Retentar erros ({stats.error})
                    </button>
                  )}
                  <button className="btn btn-ghost" onClick={reset}>
                    Nova campanha
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function StatusBadge({ status, error }) {
  const map = {
    pending: ['status-pending', '○ pendente'],
    sending: ['status-sending', '● a enviar'],
    sent:    ['status-sent',    '✓ enviado'],
    error:   ['status-error',   '✕ erro'],
  };
  const [cls, label] = map[status] || map.pending;
  return (
    <span className={`status-badge ${cls}`} title={error || ''}>
      {label}
    </span>
  );
}
