#!/bin/bash
echo "🚀 A instalar dependências..."

cd backend && npm install --silent
cd ../frontend && npm install --silent

echo ""
echo "✅ Dependências instaladas."
echo ""
echo "▶ A arrancar servidores..."
echo "   Backend  → http://localhost:3001"
echo "   Frontend → http://localhost:3000"
echo ""

# Start backend
cd ../backend && node server.js &
BACKEND_PID=$!

# Start frontend
cd ../frontend && npm start &
FRONTEND_PID=$!

# Handle Ctrl+C
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit" INT

wait
